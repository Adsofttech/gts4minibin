﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_dnd_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_system_dnd_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'Main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 162,
              day_startY: 110,
              day_sc_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              day_tc_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              day_en_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 236,
              month_startY: 110,
              month_sc_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              month_tc_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              month_en_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 40,
              y: 111,
              image_array: ["PWR_1.png","PWR_2.png","PWR_3.png","PWR_4.png","PWR_5.png","PWR_6.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 245,
              y: 172,
              src: 'Solar.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 39,
              y: 133,
              src: 'Bell.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 73,
              y: 112,
              week_en: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_tc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_sc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 71,
              am_y: 163,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 69,
              pm_y: 163,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 41,
              hour_startY: 186,
              hour_array: ["Time_00.png","Time_01.png","Time_02.png","Time_03.png","Time_04.png","Time_05.png","Time_06.png","Time_07.png","Time_08.png","Time_09.png"],
              hour_zero: 0,
              hour_space: 8,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 148,
              minute_startY: 186,
              minute_array: ["Time_00.png","Time_01.png","Time_02.png","Time_03.png","Time_04.png","Time_05.png","Time_06.png","Time_07.png","Time_08.png","Time_09.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 235,
              second_startY: 204,
              second_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'Main.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 40,
              y: 111,
              image_array: ["PWR_1.png","PWR_2.png","PWR_3.png","PWR_4.png","PWR_5.png","PWR_6.png"],
              image_length: 6,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 162,
              day_startY: 110,
              day_sc_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              day_tc_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              day_en_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 236,
              month_startY: 110,
              month_sc_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              month_tc_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              month_en_array: ["Date_00.png","Date_01.png","Date_02.png","Date_03.png","Date_04.png","Date_05.png","Date_06.png","Date_07.png","Date_08.png","Date_09.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 245,
              y: 172,
              src: 'Solar.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 39,
              y: 133,
              src: 'Bell.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 73,
              y: 112,
              week_en: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_tc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              week_sc: ["Day_01.png","Day_02.png","Day_03.png","Day_04.png","Day_05.png","Day_06.png","Day_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 71,
              am_y: 163,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 69,
              pm_y: 163,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 41,
              hour_startY: 186,
              hour_array: ["Time_00.png","Time_01.png","Time_02.png","Time_03.png","Time_04.png","Time_05.png","Time_06.png","Time_07.png","Time_08.png","Time_09.png"],
              hour_zero: 0,
              hour_space: 8,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 148,
              minute_startY: 186,
              minute_array: ["Time_00.png","Time_01.png","Time_02.png","Time_03.png","Time_04.png","Time_05.png","Time_06.png","Time_07.png","Time_08.png","Time_09.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 235,
              second_startY: 204,
              second_array: ["Sec_00.png","Sec_01.png","Sec_02.png","Sec_03.png","Sec_04.png","Sec_05.png","Sec_06.png","Sec_07.png","Sec_08.png","Sec_09.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
