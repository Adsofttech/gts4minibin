﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 162,
              y: 263,
              src: 'blueth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 141,
              y: 327,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 338,
              font_array: ["nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png","nm_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 287,
              y: 319,
              image_array: ["pu_1.png","pu_2.png","pu_3.png","pu_4.png","pu_5.png","pu_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 339,
              font_array: ["nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png","nm_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 62,
              y: 260,
              font_array: ["nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png","nm_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 260,
              font_array: ["nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png","nm_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 178,
              month_startY: 14,
              month_sc_array: ["nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png","nm_10.png"],
              month_tc_array: ["nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png","nm_10.png"],
              month_en_array: ["nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png","nm_10.png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 130,
              day_startY: 14,
              day_sc_array: ["nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png","nm_10.png"],
              day_tc_array: ["nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png","nm_10.png"],
              day_en_array: ["nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png","nm_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 165,
              y: 14,
              src: 'nm_11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 79,
              y: 46,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 105,
              font_array: ["nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png","nm_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'nm_25.png',
              unit_tc: 'nm_25.png',
              unit_en: 'nm_25.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 67,
              y: 105,
              font_array: ["nm_1.png","nm_2.png","nm_3.png","nm_4.png","nm_5.png","nm_6.png","nm_7.png","nm_8.png","nm_9.png","nm_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'grad.png',
              unit_tc: 'grad.png',
              unit_en: 'grad.png',
              negative_image: 'nm_24.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 151,
              y: 103,
              image_array: ["wz_0.png","wz_1.png","wz_2.png","wz_3.png","wz_4.png","wz_5.png","wz_6.png","wz_7.png","wz_8.png","wz_9.png","wz_10.png","wz_11.png","wz_12.png","wz_13.png","wz_14.png","wz_15.png","wz_16.png","wz_17.png","wz_18.png","wz_19.png","wz_20.png","wz_21.png","wz_22.png","wz_23.png","wz_24.png","wz_25.png","wz_26.png","wz_27.png","wz_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 7,
              hour_startY: 154,
              hour_array: ["11_(0).png","11_(1).png","11_(2).png","11_(3).png","11_(4).png","11_(5).png","11_(6).png","11_(7).png","11_(8).png","11_(9).png"],
              hour_zero: 1,
              hour_space: -3,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 120,
              minute_startY: 154,
              minute_array: ["11_(0).png","11_(1).png","11_(2).png","11_(3).png","11_(4).png","11_(5).png","11_(6).png","11_(7).png","11_(8).png","11_(9).png"],
              minute_zero: 1,
              minute_space: -3,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 233,
              second_startY: 173,
              second_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png"],
              second_zero: 1,
              second_space: -3,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 103,
              y: 164,
              src: 'rzd.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 216,
              y: 164,
              src: 'rzd.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 33,
              y: 76,
              w: 114,
              h: 75,
              src: 'null.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 314,
              w: 123,
              h: 64,
              src: 'null.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 231,
              w: 134,
              h: 77,
              src: 'null.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
