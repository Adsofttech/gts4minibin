﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'back1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 261,
              y: 254,
              font_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 281,
              y: 236,
              src: '0069_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 26,
              y: 165,
              image_array: ["steps_1.png","steps_2.png","steps_3.png","steps_4.png","steps_5.png","steps_6.png","steps_7.png","steps_8.png","steps_9.png","steps_10.png","steps_11.png","steps_12.png","steps_13.png","steps_14.png","steps_15.png","steps_16.png","steps_17.png","steps_18.png","steps_19.png","steps_20.png","steps_21.png","steps_22.png","steps_23.png","steps_24.png","steps_25.png","steps_26.png","steps_27.png","steps_28.png","steps_29.png","steps_30.png","steps_31.png","steps_32.png","steps_33.png","steps_34.png","steps_35.png","steps_36.png","steps_37.png","steps_38.png","steps_39.png","steps_40.png","steps_41.png","steps_42.png","steps_43.png","steps_44.png","steps_45.png","steps_46.png","steps_47.png","steps_48.png","steps_49.png","steps_50.png"],
              image_length: 50,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 85,
              y: 182,
              src: 'bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 237,
              y: 182,
              src: 'alarm-small3.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 123,
              y: 182,
              week_en: ["0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
              week_tc: ["0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
              week_sc: ["0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 271,
              y: 134,
              font_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0031.png',
              unit_tc: '0031.png',
              unit_en: '0031.png',
              negative_image: '0032.png',
              invalid_image: '0032.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 278,
              y: 101,
              image_array: ["weather_0.png","weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 254,
              font_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 41,
              y: 236,
              src: '0069_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 134,
              font_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 43,
              y: 106,
              image_array: ["0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 190,
              month_startY: 185,
              month_sc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              month_tc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              month_en_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 160,
              day_startY: 185,
              day_sc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              day_tc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              day_en_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 52,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 82,
              minute_startY: 236,
              minute_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 187,
              y: 185,
              src: '0033.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: 'back_aod.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 123,
              y: 182,
              week_en: ["0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
              week_tc: ["0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
              week_sc: ["0072.png","0073.png","0074.png","0075.png","0076.png","0077.png","0078.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 190,
              month_startY: 185,
              month_sc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              month_tc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              month_en_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 160,
              day_startY: 185,
              day_sc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              day_tc_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              day_en_array: ["0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 52,
              hour_array: ["0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 82,
              minute_startY: 236,
              minute_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 187,
              y: 185,
              src: '0033.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  