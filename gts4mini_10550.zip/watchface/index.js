    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright � CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_system_disconnect_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 336,
              // h: 384,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'bg_edit_1_preview.png', path: 'f001.png' },
                { id: 2, preview: 'bg_edit_2_preview.png', path: 'f002.png' },
                { id: 3, preview: 'bg_edit_3_preview.png', path: 'f003.png' },
                { id: 4, preview: 'bg_edit_4_preview.png', path: 'f004.png' },
                { id: 5, preview: 'bg_edit_5_preview.png', path: 'f005.png' },
                { id: 6, preview: 'bg_edit_6_preview.png', path: 'f006.png' },
                { id: 7, preview: 'bg_edit_7_preview.png', path: 'f007.png' },
                { id: 8, preview: 'bg_edit_8_preview.png', path: 'f008.png' },
                { id: 9, preview: 'bg_edit_9_preview.png', path: 'f009.png' },
              ],
              count: 9,
              default_id: 1,
              fg: '.png',
              tips_bg: '.png',
              tips_x: 0,
              tips_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 103,
              y: 237,
              src: '096bl.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 152,
              y: 290,
              font_array: ["030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png"],
              padding: false,
              h_space: -3,
              unit_sc: '093.png',
              unit_tc: '093.png',
              unit_en: '093.png',
              negative_image: '094.png',
              invalid_image: '095.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 150,
              y: 343,
              image_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 256,
              y: 237,
              font_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              padding: true,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 151,
              y: 235,
              font_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              padding: true,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 25,
              y: 235,
              font_array: ["040.png","041.png","042.png","043.png","044.png","045.png","046.png","047.png","048.png","049.png"],
              padding: true,
              h_space: -2,
              unit_sc: '093z.png',
              unit_tc: '093z.png',
              unit_en: '093z.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 39,
              y: 284,
              image_array: ["060.png","061.png","062.png","063.png","064.png","065.png","066.png","067.png","068.png","069.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 177,
              year_startY: 67,
              year_sc_array: ["030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png"],
              year_tc_array: ["030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png"],
              year_en_array: ["030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png"],
              year_zero: 1,
              year_space: -4,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 168,
              y: 69,
              src: '092d.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 118,
              month_startY: 67,
              month_sc_array: ["030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png"],
              month_tc_array: ["030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png"],
              month_en_array: ["030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png"],
              month_zero: 1,
              month_space: -4,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 109,
              y: 69,
              src: '092d.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 58,
              day_startY: 67,
              day_sc_array: ["030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png"],
              day_tc_array: ["030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png"],
              day_en_array: ["030.png","031.png","032.png","033.png","034.png","035.png","036.png","037.png","038.png","039.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 77,
              y: 34,
              week_en: ["050.png","051.png","052.png","053.png","054.png","055.png","056.png"],
              week_tc: ["050.png","051.png","052.png","053.png","054.png","055.png","056.png"],
              week_sc: ["050.png","051.png","052.png","053.png","054.png","055.png","056.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 20,
              hour_startY: 134,
              hour_array: ["010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_align: hmUI.align.LEFT,

              minute_startX: 129,
              minute_startY: 134,
              minute_array: ["010.png","011.png","012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 250,
              second_startY: 134,
              second_array: ["020.png","021.png","022.png","023.png","024.png","025.png","026.png","027.png","028.png","029.png"],
              second_zero: 1,
              second_space: -3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'f0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 114,
              y: 134,
              src: '090.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 243,
              y: 126,
              w: 76,
              h: 74,
              src: '099.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 96,
              y: 203,
              w: 47,
              h: 66,
              src: '099.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 151,
              y: 285,
              w: 128,
              h: 86,
              src: '099.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 61,
              y: 2,
              w: 205,
              h: 32,
              src: '099.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 240,
              y: 204,
              w: 78,
              h: 67,
              src: '099.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 144,
              y: 202,
              w: 86,
              h: 68,
              src: '099.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


// ���������
hmUI.createWidget(hmUI.widget.BUTTON, {
     x: 64,        // ���������� ������ X
     y: 41,      // ���������� ������ Y
     w: 222,       // ������ ������
     h: 72,      // ������ ������
     text: '',      // ����� ����� �������� �����, ������� ����� �� ������
     normal_src: 'blank.png',         // �������� ������, ��� ������
     press_src: 'blank.png',           // �������� ������ ��� �������, ��� ������
     click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });         // ��� ��� ���������� ������ ����������
     },
     show_level: hmUI.show_level.ONLY_NORMAL,
});


// ����� ����������
hmUI.createWidget(hmUI.widget.BUTTON, {
     x: 93,        // ���������� ������ X
     y: 0,      // ���������� ������ Y
     w: 152,       // ������ ������
     h: 32,      // ������ ������
     text: '',      // ����� ����� �������� �����, ������� ����� �� ������
     normal_src: 'blank.png',         // �������� ������, ��� ������
     press_src: 'blank.png',           // �������� ������ ��� �������, ��� ������
     click_func: () => {
	hmApp.startApp({ url: "WatchFaceScreen", native: true });         // ��� ��� ���������� ������ ����������
     },
     show_level: hmUI.show_level.ONLY_NORMAL,
});


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
