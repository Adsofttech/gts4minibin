﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 4,
              y: 187,
              src: '0163.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 4,
              y: 126,
              src: '0164.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 4,
              y: 280,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png","moon_9.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 34,
              y: 20,
              src: '0049.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: -8,
              y: 254,
              font_array: ["0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png","0089.png","0090.png","0091.png"],
              padding: false,
              h_space: -29,
              unit_sc: '0095.png',
              unit_tc: '0095.png',
              unit_en: '0095.png',
              negative_image: '0094.png',
              invalid_image: '0044.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 73,
              y: 221,
              image_array: ["0110.png","0111.png","0112.png","0113.png","0114.png","0115.png","0116.png","0117.png","0118.png","0119.png","0120.png","0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png","0128.png","0129.png","0130.png","0131.png","0132.png","0133.png","0134.png","0135.png","0136.png","0137.png","0138.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 33,
              y: 54,
              src: '0050.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 39,
              y: 16,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: -26,
              unit_sc: '0058.png',
              unit_tc: '0058.png',
              unit_en: '0058.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 39,
              y: 47,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: -26,
              unit_sc: '0057.png',
              unit_tc: '0057.png',
              unit_en: '0057.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 246,
              y: 246,
              src: '0045.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 237,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: -26,
              unit_sc: '0057.png',
              unit_tc: '0057.png',
              unit_en: '0057.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 56,
              src: '0047.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 151,
              y: 47,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: -26,
              unit_sc: '0059.png',
              unit_tc: '0059.png',
              unit_en: '0059.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 150,
              y: 17,
              src: '0046.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 16,
              font_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              padding: false,
              h_space: -26,
              unit_sc: '0055.png',
              unit_tc: '0055.png',
              unit_en: '0055.png',
              imperial_unit_sc: '0056.png',
              imperial_unit_tc: '0056.png',
              imperial_unit_en: '0056.png',
              dot_image: '0040.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 124,
              day_startY: 109,
              day_sc_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              day_tc_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              day_en_array: ["0030.png","0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png"],
              day_zero: 1,
              day_space: -26,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 174,
              y: 105,
              week_en: ["0222.png","0223.png","0224.png","0225.png","0226.png","0227.png","0228.png"],
              week_tc: ["0222.png","0223.png","0224.png","0225.png","0226.png","0227.png","0228.png"],
              week_sc: ["0222.png","0223.png","0224.png","0225.png","0226.png","0227.png","0228.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 173,
              month_startY: 87,
              month_sc_array: ["0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png","0220.png","0221.png"],
              month_tc_array: ["0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png","0220.png","0221.png"],
              month_en_array: ["0210.png","0211.png","0212.png","0213.png","0214.png","0215.png","0216.png","0217.png","0218.png","0219.png","0220.png","0221.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 340,
              am_y: 142,
              am_sc_path: '0051.png',
              am_en_path: '0051.png',
              pm_x: 340,
              pm_y: 142,
              pm_sc_path: '0052.png',
              pm_en_path: '0052.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 39,
              hour_startY: 121,
              hour_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              hour_zero: 1,
              hour_space: -65,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 130,
              minute_startY: 121,
              minute_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              minute_zero: 1,
              minute_space: -65,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 226,
              second_startY: 158,
              second_array: ["0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png"],
              second_zero: 1,
              second_space: -66,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 340,
              am_y: 142,
              am_sc_path: '0051.png',
              am_en_path: '0051.png',
              pm_x: 340,
              pm_y: 142,
              pm_sc_path: '0052.png',
              pm_en_path: '0052.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 39,
              hour_startY: 121,
              hour_array: ["0140.png","0141.png","0142.png","0143.png","0144.png","0145.png","0146.png","0147.png","0148.png","0149.png"],
              hour_zero: 1,
              hour_space: -65,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 130,
              minute_startY: 121,
              minute_array: ["0150.png","0151.png","0152.png","0153.png","0154.png","0155.png","0156.png","0157.png","0158.png","0159.png"],
              minute_zero: 1,
              minute_space: -65,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 25,
              // disconneсnt_toast_text: Bluetooth lost,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth lost"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 43,
              y: 96,
              src: '0105.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}