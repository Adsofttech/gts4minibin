﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: '0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 2,
              font_array: ["72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png"],
              padding: false,
              h_space: 1,
              unit_sc: '82.png',
              unit_tc: '82.png',
              unit_en: '82.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 35,
              day_startY: 266,
              day_sc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_tc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_en_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 59,
              y: 348,
              font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 162,
              y: 187,
              image_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png"],
              image_length: 11,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 72,
              y: 38,
              week_en: ["65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              week_tc: ["65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              week_sc: ["65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 37,
              month_startY: 100,
              month_sc_array: ["53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png"],
              month_tc_array: ["53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png"],
              month_en_array: ["53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 123,
              hour_startY: 67,
              hour_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 123,
              minute_startY: 197,
              minute_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 35,
              day_startY: 266,
              day_sc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_tc_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_en_array: ["43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 72,
              y: 38,
              week_en: ["65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              week_tc: ["65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              week_sc: ["65.png","66.png","67.png","68.png","69.png","70.png","71.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 37,
              month_startY: 100,
              month_sc_array: ["53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png"],
              month_tc_array: ["53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png"],
              month_en_array: ["53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 123,
              hour_startY: 67,
              hour_array: ["23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 123,
              minute_startY: 197,
              minute_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
