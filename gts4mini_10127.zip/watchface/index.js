﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_frame_animation_1 = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_uvi_icon_img = ''
        let editableZone_1_battery_linear_scale = null;
        let editGroup_1  = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 154,
              y: 136,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 12,
              anim_size: 19,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 205,
              y: 276,
              week_en: ["135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              week_tc: ["135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              week_sc: ["135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 149,
              day_startY: 274,
              day_sc_array: ["110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png"],
              day_tc_array: ["110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png"],
              day_en_array: ["110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 54,
              month_startY: 274,
              month_sc_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              month_tc_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              month_en_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 47,
              hour_startY: 138,
              hour_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 182,
              minute_startY: 138,
              minute_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 205,
              y: 276,
              week_en: ["135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              week_tc: ["135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              week_sc: ["135.png","136.png","137.png","138.png","139.png","140.png","141.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 149,
              day_startY: 274,
              day_sc_array: ["110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png"],
              day_tc_array: ["110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png"],
              day_en_array: ["110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 54,
              month_startY: 274,
              month_sc_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              month_tc_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              month_en_array: ["120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 47,
              hour_startY: 138,
              hour_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 182,
              minute_startY: 138,
              minute_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 154,
              y: 136,
              src: 'time.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'IMG_3157.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 105,
              y: 43,
              w: 133,
              h: 74,
              select_image: 'select.png',
              un_select_image: 'unselect.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: 'ez(1)_BATTERY.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(1)_WEATHER.png' },
              ],
              count: 4,
              tips_BG: 'tips.png',
              tips_x: 9,
              tips_y: 85,
              tips_width: 108,
              tips_margin: 3,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_1_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
                };

                // editableZone_1_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
                  // start_x: 107,
                  // start_y: 80,
                  // color: 0xFF00FF00,
                  // lenght: 41,
                  // line_width: 22,
                  // vertical: False,
                  // mirror: False,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                battery.addEventListener(hmSensor.event.CHANGE, function() {
                  scale_call();
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 105,
                  y: 65,
                  src: 'png-clipart-battery-charger-computer-icons-electric-battery-iphone-iphone-electronics-rectangle.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 165,
                  y: 74,
                  font_array: ["150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'foiz.png',
                  unit_tc: 'foiz.png',
                  unit_en: 'foiz.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 100,
                  y: 65,
                  src: 'steps.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 156,
                  y: 74,
                  font_array: ["150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.LEFT,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 103,
                  y: 62,
                  src: 'heart.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 159,
                  y: 74,
                  font_array: ["150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 167,
                  y: 74,
                  font_array: ["150.png","151.png","152.png","153.png","154.png","155.png","156.png","157.png","158.png","159.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'white_small_du_120.png',
                  unit_tc: 'white_small_du_120.png',
                  unit_en: 'white_small_du_120.png',
                  negative_image: 'minus.png',
                  invalid_image: 'soroq.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 121,
                  y: 68,
                  image_array: ["0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            function scale_call() {

                console.log('update editable linear_scale BATTERY');
                
                let valueBattery= battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_editableZone_1_battery = progressBattery;

                if (editableZone_1_battery_linear_scale) {

                  // editableZone_1_battery_linear_scale
                  // initial parameters
                  let start_x_editableZone_1_battery = 107;
                  let start_y_editableZone_1_battery = 80;
                  let lenght_ls_editableZone_1_battery = 41;
                  let line_width_ls_editableZone_1_battery = 22;
                  let color_ls_editableZone_1_battery = 0xFF00FF00;
                  
                  // calculated parameters
                  let start_x_editableZone_1_battery_draw = start_x_editableZone_1_battery;
                  let start_y_editableZone_1_battery_draw = start_y_editableZone_1_battery;
                  lenght_ls_editableZone_1_battery = lenght_ls_editableZone_1_battery * progress_ls_editableZone_1_battery;
                  let lenght_ls_editableZone_1_battery_draw = lenght_ls_editableZone_1_battery;
                  let line_width_ls_editableZone_1_battery_draw = line_width_ls_editableZone_1_battery;
                  if (lenght_ls_editableZone_1_battery < 0){
                    lenght_ls_editableZone_1_battery_draw = -lenght_ls_editableZone_1_battery;
                    start_x_editableZone_1_battery_draw = start_x_editableZone_1_battery - lenght_ls_editableZone_1_battery_draw;
                  };
                  
                  editableZone_1_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_editableZone_1_battery_draw,
                    y: start_y_editableZone_1_battery_draw,
                    w: lenght_ls_editableZone_1_battery_draw,
                    h: line_width_ls_editableZone_1_battery_draw,
                    color: color_ls_editableZone_1_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  