﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 388,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 34,
              y: 99,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 11,
              y: 36,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 40,
              y: 128,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 320,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'pointer_2.png',
              unit_tc: 'pointer_2.png',
              unit_en: 'pointer_2.png',
              negative_image: 'pointer_1.png',
              invalid_image: 'dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 294,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'pointer_2.png',
              unit_tc: 'pointer_2.png',
              unit_en: 'pointer_2.png',
              negative_image: 'pointer_1.png',
              invalid_image: 'dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 197,
              y: 347,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'pointer_2.png',
              unit_tc: 'pointer_2.png',
              unit_en: 'pointer_2.png',
              negative_image: 'pointer_1.png',
              invalid_image: 'dot.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 243,
              y: 290,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 27,
              y: 256,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'pointer_0.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 38,
              y: 209,
              font_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 305,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 340,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 158,
              y: 246,
              font_array: ["font_step_0.png","font_step_1.png","font_step_2.png","font_step_3.png","font_step_4.png","font_step_5.png","font_step_6.png","font_step_7.png","font_step_8.png","font_step_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 105,
              y: 221,
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 159,
              y: 45,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 227,
              day_startY: 52,
              day_sc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_tc_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_en_array: ["font_day_0.png","font_day_1.png","font_day_2.png","font_day_3.png","font_day_4.png","font_day_5.png","font_day_6.png","font_day_7.png","font_day_8.png","font_day_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 131,
              hour_startY: 88,
              hour_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              hour_zero: 0,
              hour_space: 3,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 223,
              minute_startY: 88,
              minute_array: ["font_0.png","font_1.png","font_2.png","font_3.png","font_4.png","font_5.png","font_6.png","font_7.png","font_8.png","font_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
