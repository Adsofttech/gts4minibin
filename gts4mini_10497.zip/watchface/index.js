﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_digital_clock_img_time = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let idle_background_bg = ''
        let idle_step_circle_scale = ''
        let idle_step_circle_scale_mirror = ''
        let idle_step_current_text_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_circle_scale_mirror = ''
        let idle_battery_text_text_img = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_digital_clock_img_time = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 364,
              font_array: ["d-dim-0000.png","d-dim-0001.png","d-dim-0002.png","d-dim-0003.png","d-dim-0004.png","d-dim-0005.png","d-dim-0006.png","d-dim-0007.png","d-dim-0008.png","d-dim-0009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 8,
              font_array: ["d-dim-0000.png","d-dim-0001.png","d-dim-0002.png","d-dim-0003.png","d-dim-0004.png","d-dim-0005.png","d-dim-0006.png","d-dim-0007.png","d-dim-0008.png","d-dim-0009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'a-min-dim.png',
              minute_centerX: 168,
              minute_centerY: 194,
              minute_posX: 168,
              minute_posY: 168,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'a-sec.png',
              second_centerX: 168,
              second_centerY: 194,
              second_posX: 168,
              second_posY: 168,
              second_cover_path: 'select-full.png',
              second_cover_x: 0,
              second_cover_y: 25,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'empty.png',
              hour_centerX: 0,
              hour_centerY: 0,
              hour_posX: 0,
              hour_posY: 0,
              hour_cover_path: 'select-date.png',
              hour_cover_x: 0,
              hour_cover_y: 25,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 121,
              hour_startY: 161,
              hour_array: ["d-hh-0000.png","d-hh-0001.png","d-hh-0002.png","d-hh-0003.png","d-hh-0004.png","d-hh-0005.png","d-hh-0006.png","d-hh-0007.png","d-hh-0008.png","d-hh-0009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 232,
              minute_startY: 178,
              minute_array: ["d-mm-0000.png","d-mm-0001.png","d-mm-0002.png","d-mm-0003.png","d-mm-0004.png","d-mm-0005.png","d-mm-0006.png","d-mm-0007.png","d-mm-0008.png","d-mm-0009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 62,
              day_startY: 178,
              day_sc_array: ["d-mm-0000.png","d-mm-0001.png","d-mm-0002.png","d-mm-0003.png","d-mm-0004.png","d-mm-0005.png","d-mm-0006.png","d-mm-0007.png","d-mm-0008.png","d-mm-0009.png"],
              day_tc_array: ["d-mm-0000.png","d-mm-0001.png","d-mm-0002.png","d-mm-0003.png","d-mm-0004.png","d-mm-0005.png","d-mm-0006.png","d-mm-0007.png","d-mm-0008.png","d-mm-0009.png"],
              day_en_array: ["d-mm-0000.png","d-mm-0001.png","d-mm-0002.png","d-mm-0003.png","d-mm-0004.png","d-mm-0005.png","d-mm-0006.png","d-mm-0007.png","d-mm-0008.png","d-mm-0009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 16,
              month_startY: 186,
              month_sc_array: ["d-ss-0000.png","d-ss-0001.png","d-ss-0002.png","d-ss-0003.png","d-ss-0004.png","d-ss-0005.png","d-ss-0006.png","d-ss-0007.png","d-ss-0008.png","d-ss-0009.png"],
              month_tc_array: ["d-ss-0000.png","d-ss-0001.png","d-ss-0002.png","d-ss-0003.png","d-ss-0004.png","d-ss-0005.png","d-ss-0006.png","d-ss-0007.png","d-ss-0008.png","d-ss-0009.png"],
              month_en_array: ["d-ss-0000.png","d-ss-0001.png","d-ss-0002.png","d-ss-0003.png","d-ss-0004.png","d-ss-0005.png","d-ss-0006.png","d-ss-0007.png","d-ss-0008.png","d-ss-0009.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 136,
              font_array: ["d-dim-0000.png","d-dim-0001.png","d-dim-0002.png","d-dim-0003.png","d-dim-0004.png","d-dim-0005.png","d-dim-0006.png","d-dim-0007.png","d-dim-0008.png","d-dim-0009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'd-dim-up.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 237,
              font_array: ["d-dim-0000.png","d-dim-0001.png","d-dim-0002.png","d-dim-0003.png","d-dim-0004.png","d-dim-0005.png","d-dim-0006.png","d-dim-0007.png","d-dim-0008.png","d-dim-0009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'd-dim-down.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              color: '0xFFFFFFFF',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 168,
              // center_y: 194,
              // start_angle: 180,
              // end_angle: 100,
              // radius: 171,
              // line_width: 3,
              // color: 0xFF424242,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
              idle_step_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 138,
              y: 364,
              font_array: ["d-dim-0000.png","d-dim-0001.png","d-dim-0002.png","d-dim-0003.png","d-dim-0004.png","d-dim-0005.png","d-dim-0006.png","d-dim-0007.png","d-dim-0008.png","d-dim-0009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 168,
              // center_y: 195,
              // start_angle: 0,
              // end_angle: 80,
              // radius: 172,
              // line_width: 3,
              // color: 0xFF424242,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
              idle_battery_circle_scale_mirror = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 8,
              font_array: ["d-dim-0000.png","d-dim-0001.png","d-dim-0002.png","d-dim-0003.png","d-dim-0004.png","d-dim-0005.png","d-dim-0006.png","d-dim-0007.png","d-dim-0008.png","d-dim-0009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'a-min-dim.png',
              minute_centerX: 168,
              minute_centerY: 194,
              minute_posX: 168,
              minute_posY: 168,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'a-sec.png',
              second_centerX: 168,
              second_centerY: 194,
              second_posX: 168,
              second_posY: 168,
              second_cover_path: 'select-full.png',
              second_cover_x: 0,
              second_cover_y: 25,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'empty.png',
              hour_centerX: 0,
              hour_centerY: 0,
              hour_posX: 0,
              hour_posY: 0,
              hour_cover_path: 'select-date.png',
              hour_cover_x: 0,
              hour_cover_y: 25,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 121,
              hour_startY: 161,
              hour_array: ["d-hh-0000.png","d-hh-0001.png","d-hh-0002.png","d-hh-0003.png","d-hh-0004.png","d-hh-0005.png","d-hh-0006.png","d-hh-0007.png","d-hh-0008.png","d-hh-0009.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 232,
              minute_startY: 178,
              minute_array: ["d-mm-0000.png","d-mm-0001.png","d-mm-0002.png","d-mm-0003.png","d-mm-0004.png","d-mm-0005.png","d-mm-0006.png","d-mm-0007.png","d-mm-0008.png","d-mm-0009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 62,
              day_startY: 178,
              day_sc_array: ["d-mm-0000.png","d-mm-0001.png","d-mm-0002.png","d-mm-0003.png","d-mm-0004.png","d-mm-0005.png","d-mm-0006.png","d-mm-0007.png","d-mm-0008.png","d-mm-0009.png"],
              day_tc_array: ["d-mm-0000.png","d-mm-0001.png","d-mm-0002.png","d-mm-0003.png","d-mm-0004.png","d-mm-0005.png","d-mm-0006.png","d-mm-0007.png","d-mm-0008.png","d-mm-0009.png"],
              day_en_array: ["d-mm-0000.png","d-mm-0001.png","d-mm-0002.png","d-mm-0003.png","d-mm-0004.png","d-mm-0005.png","d-mm-0006.png","d-mm-0007.png","d-mm-0008.png","d-mm-0009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 16,
              month_startY: 186,
              month_sc_array: ["d-ss-0000.png","d-ss-0001.png","d-ss-0002.png","d-ss-0003.png","d-ss-0004.png","d-ss-0005.png","d-ss-0006.png","d-ss-0007.png","d-ss-0008.png","d-ss-0009.png"],
              month_tc_array: ["d-ss-0000.png","d-ss-0001.png","d-ss-0002.png","d-ss-0003.png","d-ss-0004.png","d-ss-0005.png","d-ss-0006.png","d-ss-0007.png","d-ss-0008.png","d-ss-0009.png"],
              month_en_array: ["d-ss-0000.png","d-ss-0001.png","d-ss-0002.png","d-ss-0003.png","d-ss-0004.png","d-ss-0005.png","d-ss-0006.png","d-ss-0007.png","d-ss-0008.png","d-ss-0009.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 136,
              font_array: ["d-dim-0000.png","d-dim-0001.png","d-dim-0002.png","d-dim-0003.png","d-dim-0004.png","d-dim-0005.png","d-dim-0006.png","d-dim-0007.png","d-dim-0008.png","d-dim-0009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'd-dim-up.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 132,
              y: 237,
              font_array: ["d-dim-0000.png","d-dim-0001.png","d-dim-0002.png","d-dim-0003.png","d-dim-0004.png","d-dim-0005.png","d-dim-0006.png","d-dim-0007.png","d-dim-0008.png","d-dim-0009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'd-dim-down.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale
                  // initial parameters
                  let start_angle_idle_step = 90;
                  let end_angle_idle_step = 10;
                  let center_x_idle_step = 168;
                  let center_y_idle_step = 194;
                  let radius_idle_step = 171;
                  let line_width_cs_idle_step = 3;
                  let color_cs_idle_step = 0xFF424242;
                  
                  // calculated parameters
                  let arcX_idle_step = center_x_idle_step - radius_idle_step;
                  let arcY_idle_step = center_y_idle_step - radius_idle_step;
                  let CircleWidth_idle_step = 2 * radius_idle_step;
                  let angle_offset_idle_step = end_angle_idle_step - start_angle_idle_step;
                  angle_offset_idle_step = angle_offset_idle_step * progress_cs_idle_step;
                  let end_angle_idle_step_draw = start_angle_idle_step + angle_offset_idle_step;
                  
                  idle_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step,
                    end_angle: end_angle_idle_step_draw,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                  
                  // idle_step_circle_scale_mirror
                  // initial parameters mirror
                  let start_angle_idle_step_mirror = 90;
                  let end_angle_idle_step_mirror = 170;
                  
                  // calculated parameters mirror
                  let angle_offset_idle_step_mirror = end_angle_idle_step_mirror - start_angle_idle_step_mirror;
                  angle_offset_idle_step_mirror = angle_offset_idle_step_mirror * progress_cs_idle_step;
                  let end_angle_idle_step_draw_mirror = start_angle_idle_step_mirror + angle_offset_idle_step_mirror;
                  
                  idle_step_circle_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step_mirror,
                    end_angle: end_angle_idle_step_draw_mirror,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale
                  // initial parameters
                  let start_angle_idle_battery = -90;
                  let end_angle_idle_battery = -10;
                  let center_x_idle_battery = 168;
                  let center_y_idle_battery = 195;
                  let radius_idle_battery = 172;
                  let line_width_cs_idle_battery = 3;
                  let color_cs_idle_battery = 0xFF424242;
                  
                  // calculated parameters
                  let arcX_idle_battery = center_x_idle_battery - radius_idle_battery;
                  let arcY_idle_battery = center_y_idle_battery - radius_idle_battery;
                  let CircleWidth_idle_battery = 2 * radius_idle_battery;
                  let angle_offset_idle_battery = end_angle_idle_battery - start_angle_idle_battery;
                  angle_offset_idle_battery = angle_offset_idle_battery * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw = start_angle_idle_battery + angle_offset_idle_battery;
                  
                  idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery,
                    end_angle: end_angle_idle_battery_draw,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                  
                  // idle_battery_circle_scale_mirror
                  // initial parameters mirror
                  let start_angle_idle_battery_mirror = -90;
                  let end_angle_idle_battery_mirror = -170;
                  
                  // calculated parameters mirror
                  let angle_offset_idle_battery_mirror = end_angle_idle_battery_mirror - start_angle_idle_battery_mirror;
                  angle_offset_idle_battery_mirror = angle_offset_idle_battery_mirror * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw_mirror = start_angle_idle_battery_mirror + angle_offset_idle_battery_mirror;
                  
                  idle_battery_circle_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery_mirror,
                    end_angle: end_angle_idle_battery_draw_mirror,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
