﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_stand_circle_scale = ''
        let normal_pai_circle_scale = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_humidity_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 336,
              h: 384,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0018.png',
              center_x: 167,
              center_y: 194,
              x: 0,
              y: 145,
              start_angle: 299,
              end_angle: 318,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 164,
              y: 5,
              src: '0013.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 161,
              y: 28,
              src: '0014.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 101,
              y: 29,
              font_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'celsius-degrees-symbol-of-temperature (1).png',
              unit_tc: 'celsius-degrees-symbol-of-temperature (1).png',
              unit_en: 'celsius-degrees-symbol-of-temperature (1).png',
              negative_image: '0068.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 25,
              y: 80,
              font_array: ["0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png"],
              padding: false,
              h_space: -3,
              unit_sc: 'celsius-degrees-symbol-of-temperature (1).png',
              unit_tc: 'celsius-degrees-symbol-of-temperature (1).png',
              unit_en: 'celsius-degrees-symbol-of-temperature (1).png',
              negative_image: '0068.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 31,
              y: 20,
              font_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'celsius-degrees-symbol-of-temperature.png',
              unit_tc: 'celsius-degrees-symbol-of-temperature.png',
              unit_en: 'celsius-degrees-symbol-of-temperature.png',
              negative_image: '0069.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 169,
              // center_y: 361,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 7,
              // line_width: 3,
              // color: 0xFF69008C,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 169,
              // center_y: 361,
              // start_angle: 0,
              // end_angle: 359,
              // radius: 18,
              // line_width: 3,
              // color: 0xFF69008C,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            // normal_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 169,
              // center_y: 361,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 13,
              // line_width: 3,
              // color: 0xFF69008C,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 271,
              day_startY: 19,
              day_sc_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
              day_tc_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
              day_en_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
              day_zero: 1,
              day_space: -3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 221,
              y: 28,
              week_en: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              week_tc: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              week_sc: ["0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_humidity_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0018.png',
              center_x: 167,
              center_y: 194,
              x: 0,
              y: 169,
              start_angle: 317,
              end_angle: 332,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 12,
              y: 264,
              src: 'Step.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 166,
              // center_y: 189,
              // start_angle: 191,
              // end_angle: 235,
              // radius: 178,
              // line_width: 13,
              // color: 0xFF69008C,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0017.png',
              center_x: 167,
              center_y: 194,
              x: 0,
              y: 175,
              start_angle: 190,
              end_angle: 234,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 21,
              y: 347,
              font_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 314,
              y: 263,
              src: 'Light.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 167,
              // center_y: 190,
              // start_angle: 123,
              // end_angle: 169,
              // radius: 178,
              // line_width: 12,
              // color: 0xFF69008C,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0017.png',
              center_x: 167,
              center_y: 194,
              x: -104,
              y: 134,
              start_angle: 82,
              end_angle: 126,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 248,
              y: 345,
              font_array: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png","0035.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 72,
              hour_startY: 84,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 91,
              minute_startY: 196,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 72,
              hour_startY: 84,
              hour_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 91,
              minute_startY: 196,
              minute_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png"],
              minute_zero: 1,
              minute_space: -1,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: -3,
              w: 86,
              h: 86,
              src: '00ss71.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 12,
              y: 310,
              w: 93,
              h: 86,
              src: '00ss71.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale
                  // initial parameters
                  let start_angle_normal_calorie = -90;
                  let end_angle_normal_calorie = 270;
                  let center_x_normal_calorie = 169;
                  let center_y_normal_calorie = 361;
                  let radius_normal_calorie = 7;
                  let line_width_cs_normal_calorie = 3;
                  let color_cs_normal_calorie = 0xFF69008C;
                  
                  // calculated parameters
                  let arcX_normal_calorie = center_x_normal_calorie - radius_normal_calorie;
                  let arcY_normal_calorie = center_y_normal_calorie - radius_normal_calorie;
                  let CircleWidth_normal_calorie = 2 * radius_normal_calorie;
                  let angle_offset_normal_calorie = end_angle_normal_calorie - start_angle_normal_calorie;
                  angle_offset_normal_calorie = angle_offset_normal_calorie * progress_cs_normal_calorie;
                  let end_angle_normal_calorie_draw = start_angle_normal_calorie + angle_offset_normal_calorie;
                  
                  normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_calorie,
                    y: arcY_normal_calorie,
                    w: CircleWidth_normal_calorie,
                    h: CircleWidth_normal_calorie,
                    start_angle: start_angle_normal_calorie,
                    end_angle: end_angle_normal_calorie_draw,
                    color: color_cs_normal_calorie,
                    line_width: line_width_cs_normal_calorie,
                  });
                };

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale
                  // initial parameters
                  let start_angle_normal_stand = -90;
                  let end_angle_normal_stand = 269;
                  let center_x_normal_stand = 169;
                  let center_y_normal_stand = 361;
                  let radius_normal_stand = 18;
                  let line_width_cs_normal_stand = 3;
                  let color_cs_normal_stand = 0xFF69008C;
                  
                  // calculated parameters
                  let arcX_normal_stand = center_x_normal_stand - radius_normal_stand;
                  let arcY_normal_stand = center_y_normal_stand - radius_normal_stand;
                  let CircleWidth_normal_stand = 2 * radius_normal_stand;
                  let angle_offset_normal_stand = end_angle_normal_stand - start_angle_normal_stand;
                  angle_offset_normal_stand = angle_offset_normal_stand * progress_cs_normal_stand;
                  let end_angle_normal_stand_draw = start_angle_normal_stand + angle_offset_normal_stand;
                  
                  normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_stand,
                    y: arcY_normal_stand,
                    w: CircleWidth_normal_stand,
                    h: CircleWidth_normal_stand,
                    start_angle: start_angle_normal_stand,
                    end_angle: end_angle_normal_stand_draw,
                    color: color_cs_normal_stand,
                    line_width: line_width_cs_normal_stand,
                  });
                };

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_circle_scale
                  // initial parameters
                  let start_angle_normal_pai = -90;
                  let end_angle_normal_pai = 270;
                  let center_x_normal_pai = 169;
                  let center_y_normal_pai = 361;
                  let radius_normal_pai = 13;
                  let line_width_cs_normal_pai = 3;
                  let color_cs_normal_pai = 0xFF69008C;
                  
                  // calculated parameters
                  let arcX_normal_pai = center_x_normal_pai - radius_normal_pai;
                  let arcY_normal_pai = center_y_normal_pai - radius_normal_pai;
                  let CircleWidth_normal_pai = 2 * radius_normal_pai;
                  let angle_offset_normal_pai = end_angle_normal_pai - start_angle_normal_pai;
                  angle_offset_normal_pai = angle_offset_normal_pai * progress_cs_normal_pai;
                  let end_angle_normal_pai_draw = start_angle_normal_pai + angle_offset_normal_pai;
                  
                  normal_pai_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_pai,
                    y: arcY_normal_pai,
                    w: CircleWidth_normal_pai,
                    h: CircleWidth_normal_pai,
                    start_angle: start_angle_normal_pai,
                    end_angle: end_angle_normal_pai_draw,
                    color: color_cs_normal_pai,
                    line_width: line_width_cs_normal_pai,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = 101;
                  let end_angle_normal_step = 145;
                  let center_x_normal_step = 166;
                  let center_y_normal_step = 189;
                  let radius_normal_step = 178;
                  let line_width_cs_normal_step = 13;
                  let color_cs_normal_step = 0xFF69008C;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = 33;
                  let end_angle_normal_battery = 79;
                  let center_x_normal_battery = 167;
                  let center_y_normal_battery = 190;
                  let radius_normal_battery = 178;
                  let line_width_cs_normal_battery = 12;
                  let color_cs_normal_battery = 0xFF69008C;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
